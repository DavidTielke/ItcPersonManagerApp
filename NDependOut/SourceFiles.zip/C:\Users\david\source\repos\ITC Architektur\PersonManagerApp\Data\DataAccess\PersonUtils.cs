﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DavidTielke.PMA.Data.DataAccess
{
    internal class PersonUtils
    {
        public void Foo(){}
    }
}
