﻿namespace ConsoleClient;

class PersonUtils
{
    public void Foo()
    {

    }
}