﻿namespace DavidTielke.PMA.Data.FileStorage;

class FileReader
{
    public IEnumerable<string> ReadAllLines(string path)
    {
        return File.ReadAllLines(path);
    }
}