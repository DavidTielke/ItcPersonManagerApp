﻿using DavidTielke.PMA.CrossCutting.DataClasses;
using DavidTielke.PMA.Data.DataAccess;

namespace DavidTielke.PMA.Data.DataStorage;

public class PersonParser
{
    public Person ParseFromCsv(string dataLine)
    {
        var util = new PersonUtils();

        var parts = dataLine.Split(",");
        var person = new Person
        {
            Id = int.Parse(parts[0]),
            Name = parts[1],
            Age = int.Parse(parts[2]),
        };
        return person;
    }
}